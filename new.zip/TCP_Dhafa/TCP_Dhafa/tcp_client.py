from socket import *
import sys

def get(server, filename):
    clientSocket = socket(AF_INET, SOCK_STREAM)
    clientSocket.connect(server)

    request = f'GET /{filename} HTTP/1.1\r\nHost: {serverAddress}:{serverPort}\r\n\r\n'
    clientSocket.send(request.encode())
    response = clientSocket.recv(1024).decode()
    print(f'Response: {response}')

    if "200" in response: 
        f = open(filename[0:])
        outputdata = f.read()
        f.close()
        print("Isi File : \n\n", outputdata, "\n\n")

    clientSocket.close()

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print(f"format: tcp_client.py <serverAddress> <serverPort> <filename>") 
    else:
        serverAddress = sys.argv[1]
        serverPort = int(sys.argv[2])
        filename = sys.argv[3]
        server = (serverAddress, serverPort)
        get(server, filename)

